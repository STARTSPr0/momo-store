import Navbar from './Navbar.vue';

export default Navbar;