<template>
  <div class="d-flex justify-content-center align-items-center">
    <slot></slot>
  </div>
</template>
